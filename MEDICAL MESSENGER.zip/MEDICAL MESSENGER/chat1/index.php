<?php
// get username
$user = $_GET['u'];
?>
<html>
<head>
<title>Chatter</title>
<link rel='stylesheet' type'text/css' href='css/style.css' />
<link href='http://fonts.googleapls.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="javascript/chat.js"></script>
</head>
<div class='chatContainer'>
<div class='chatHeader'>
<h3>Welcome <?php echo ucwords($user); ?></h3>
</div>
<div class='chatMessages'>
<?php
// Getting these lousy messages
$db = new PDO('mysql:host=127.0.0.1;dbname=chat1','root','');

// Get messages
$query = $db->prepare("SELECT * FROM messages1");
$query->execute();

//Fetch
while($fetch = $query->fetch(PDO::FETCH_ASSOC))
{
	$name = $fetch['name'];
	$messages = $fetch['messages'];

	echo "<li class='cm'><b>".ucwords($name)."</b> - ".$messages."</li>";
}
?>
</div>
<div class='chatBottom'>
<form action='#' onSubmit='return false;' id='chatForm'>
<input type='hidden' id='name' value='<?php echo $user; ?>'/>
<input type='text' name='text' id='text' value='' placeholder='type your chat message' />
<input type='submit' name='submit' value='post' />
</form>
<div>
</div>
</body>
</html>
