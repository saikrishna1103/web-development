<?php
  // The lengandary chat poster
  $db = new PDO('mysql:host=127.0.0.1;dbname=chat1','root','');

  // secure the chat
  if(isset($_POST['text']) && isset($_POST['name']))
  {
    $text = strip_tags(stripslashes($_POST['text']));
	  $name = strip_tags(stripslashes($_POST['name']));

	  if(!empty($text) && !empty($name))
	  {
		  $insert = $db->prepare("INSERT INTO messages1 VALUES('','".$name."','".$text."')");
		  $insert->execute();

		  echo "<li class='cm'><b>".ucwords($name)."</b> - ".$text."</li>";
	  }
  }
  ?>
