
<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `users1` WHERE CONCAT('username', `d_name`, `d_place`, `specilization`, `experience`,'contact','email','bot') LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);

}
 else {
    $query = "SELECT * FROM `users1`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "test_db1");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

<!DOCTYPE html>
<html>
    <head>
        <title>PHP HTML TABLE DATA SEARCH</title>
        <center>
          <h1>doctors profile</h1>
        </center>
         <style>
            table,tr,th,td
            {
                border: 1px solid black;
            }
        </style>
    </head>
    <body>

        <form action="filter2.php" method="post">
  <h3>enter your name </h3> <input type="text" name="valueToSearch" placeholder="Value To Search"><br><br>
            <input type="submit" name="search" value="Filter"><br><br>

            <table>
                <tr>
                    <th>username</th>
                    <th>d_name</th>
                    <th>d_place</th>
                    <th>specilization</th>
                    <th>experience</th>
					          <th>contact</th>
					          <th>email</th>
			         </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr
                    <td><?php echo $row['username'];?></td>
                    <td><?php echo $row['d_name'];?></td>
                    <td><?php echo $row['d_place'];?></td>
                    <td><?php echo $row['specilization'];?></td>
                    <td><?php echo $row['experience'];?></td>
					<td><?php echo $row['contact'];?></td>
					<td><?php echo $row['email'];?></td>
      <td><input type=button id="button2" onClick="location.href='<?php echo $row['bot'];?>'"target="_blank"value='check the messages'></td>
				</tr>
                <?php endwhile;?>
            </table>
            <td><input type=button id="button2" onClick="location.href='logout.php'"target="_blank"value='logout'></td>

        </form>

    </body>
</html>
