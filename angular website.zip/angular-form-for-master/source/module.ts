/// <reference path="../definitions/angular.d.ts" />

angular.module('formFor', []);