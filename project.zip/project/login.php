<?php
include("includes/header.php");
include("includes/config.php");
include("includes/function.php");
$msg='';$msg2='';$email='';$msg3='';
if(isset($_POST['submit']))
{
  $email=$_POST['email'];
  $password=$_POST['pass'];
  if(empty($email))
  {
    $msg='<div class="error">Please enter your email</div>';
  }
  if(empty($password))
  {
    $msg2='<div class="error">please enter your password</div>';
  }
  else if(email_exists($email,$con))
  {
    $pass=mysqli_query($con,"SELECT password FROM users WHERE email='$email'");
    $pass_w=mysqli_fetch_array($pass);
    $dbpass=$pass_w['password'];
   if($password!==$dbpass)
   {
     $msg2='<div class="error"> password is wrong</div>';
   }
   else {
       header("location:profile.php");
   }
}
  else {
    $msg='<div class="error">Email Does not Exists</div>';
  }
}
 ?>
 <title>Login form</title>
 <style type="text/css">
 #body-bg
 {
   background: url("images/image1.jpg")
 }
.error
{
  color:red;
}
 </style>
</head>
<body id='body-bg'>
  <div class='container'>
    <div class='login-form col-md-4 offset-md-4'>
      <div class='jumbotron' style='margin-top:50px;padding-top:20px;padding-bottom:10px;'>
<h2 align='center'>Login form</h2></br>
        <form method='post'>
          <div class='form-group'>
            <label>Email : </label>
            <input type='email' name="email" class='form-control' value='<?php echo $email; ?>' />
           <?php echo $msg; ?>
          </div>
          <div class='form-group'>
            <label>Password : </label>
            <input type='password' name="pass" class='form-control' />
           <?php echo $msg2; ?>
          </div>
          <div class='form-group'>
            <input type='checkbox' name='check' />
            &nbsp;   Keep me Logged in
          </div></br>
          <div class='form-group'>
      <center><input type="submit" name='submit' value='Login' class='btn btn-success'/></center>
      </div>
      <center><a href='forgot.php'>Forgot Password ? </a></center>
<center><a href='index.html'>To login with google/facebook</a></center>
    </div>
  </div>
</body>
</html>
