<?php
include("includes/header.php");
include("includes/config.php");
include("includes/function.php");
$msg='';$msg2='';$msg3='';$msg4='';$email='';$date='';$password='';$cpassword='';
if(isset($_POST['submit']))
{
  $email=$_POST['email'];
  $date=$_POST['dob'];
  $password=$_POST['pass'];
  $cpassword=$_POST['cpass'];
  if(empty($email))
  {
    $msg="<div class='error'>Please enter your email</div>";
  }
  else if(empty($date))
{
    $msg2="<div class='error'>Please enter your Date of birth</div>";
}
else if(empty($password))
{
  $msg3="<div class='error'>Please enter your password</div>";
}
else if(empty($cpassword))
{
  $msg4="<div class='error'>Please enter password</div>";
}
else if($password!=$cpassword)
{
  $msg4="<div class='error'>password does not match</div>";
}
else if(email_exists($email,$con))
{
  $result=mysqli_query($con,"SELECT dob FROM users where email='$email'");
  $retrive=mysqli_fetch_array($result);
  $DOB=$retrive['dob'];
  if($date==$DOB)
  {
  mysqli_query($con,"UPDATE users SET password='$password'");
}
  else
  {
    $msg2="<div class='error'>Date of Birth id is wrong</div>";
  }
}
else{
  $msg="<div class='error'>Email Does not exists</div>";
}
}
?>
<title>forgot password</title>
</head>
<style type='text/css'>
#body-bg
{
  background: url("images/image1.jpg")
}
.error
{
  color:red;
}
.success
{
  color:green;
}

</style>
<body id='body-bg'>
<div class='container'>
  <div class='login-form col-md-4 offset-md-4'>
    <div class='jumbotron' style='margin-top:20px;padding-top:20px;padding-bottom:30px;'>
<h3 align='center'>Forgot password</h3></br
</br>
<form method='post'>
  <div class='form-group'>
    <label>Email : </label>
    <input type='email' name='email' class='form-control' placeholder='Enter your Email'>
<?php echo $msg; ?>
  </div>
  <div class='form-group'>
    <label>Date of Birth : </label>
    <input type='date' name='dob' class='form-control' >
<?php echo $msg2; ?>
  </div>

  <div class='form-group'>
    <label>New Password : </label>
    <input type='password' name='pass' class='form-control'placeholder='Enter your password' >
<?php echo $msg3; ?>
  </div>
  <div class='form-group'>
    <label>Re-enter Password : </label>
    <input type='password' name='cpass' class='form-control' placeholder='Re-enter New password' >
<?php echo $msg4; ?>
  </div>
<center><button class='btn btn-success' name='submit'>Submit</button></center>
  <center><a href='login.php'>Back to login page </a></center>
</form>
</div>
</div>
</div>
</body>
</html>
