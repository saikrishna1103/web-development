<?php
include("includes/header.php");
include("includes/config.php");
$msg='';
$msg2='';
$msg3='';
$msg4='';
$msg5='';
$msg6='';
$msg8='';
if(isset($_POST['submit']))
{
 $firstname=$_POST['fname'];
 $lastname=$_POST['lname'];
 $email=$_POST['email'];
 $date=$_POST['dob'];
 $password=$_POST['pass'];
 $c_password=$_POST['cpass'];
// $image=$_FILES['image']['name'];
 //$tmp_image=$_FILES['image']['tmp_name'];
 //echo $firstname."</br>".$lastname."</br>".$email."</br>".$date."</br>".$password."</br>"
 //.$c_password."</br>".$image."</br>".$checkbox;

if(strlen($firstname)<3)
{
  $msg="<div class='error'>First name must contain atleast 3 characters'</div>";

}
if(strlen($lastname)<3)
{
  $msg2="<div class='error'>Last name must contain atleast 3 characters</div>";
}
else if(empty($date))
{
  $msg3="<div class='error'>Please enter your date of birth</div>";
}
else if(strlen($password)<5)
{
  $msg4="<div class='error'>password must contain 5  letters</div>";
}
else if($password!==$c_password){
  $msg5="<div class='error'>Password is not same</div>";
}
//else if($image=='')
//{
  //$msg6="<div class='error'>Pls upload a image</div>";
//}
else
{
    mysqli_query($con,"INSERT INTO users
      (first_name,last_name,email,dob,password)
 VALUES ('$firstname','$lastname','$email','$date','$password')");
  $msg8="<div class='success'><center>you are successsfully registered</center> </div>";
}
}
?>
<title>Sign Up Form</title>
</head>
<style type='text/css'>
#body-bg
{
  background: url("images/image1.jpg")
}
.error
{
  color:red;
}
.success
{
  color:green;
}

</style>
<body id='body-bg'>
<div class='container'>
  <div class='login-form col-md-4 offset-md-4'>
    <div class='jumbotron' style='margin-top:20px;padding-top:20px;padding-bottom:20px;'>
<h3 align='center'>Sign Up Form</h3></br>
<?php echo $msg8; ?>
<form method='post' enctype="multipart/form-data">
  <div class="form-group">
  <label>First Name :</label>
  <input type='text' name='fname' placeholder="First Name" class='form-control'>
  <?php echo $msg; ?>
</div>
<div class="form-group">
  <label>Last Name :</label>
  <input type='text' name='lname' placeholder="Last Name" class='form-control'>
<?php echo $msg2; ?>
</div>
<div class="form-group">
  <label>Email :</label>
  <input type='email' name='email' placeholder="your Email" class='form-control'>
</div>
<div class="form-group">
  <label>Date of Birth :</label>
  <input type='date' name='dob' placeholder="Your Date of Birth" class='form-control'>
<?php echo $msg3; ?>
</div>
<div class="form-group">
  <label>Password:</label>
  <input type='pasword' name='pass' placeholder="Password" class='form-control'>
<?php echo $msg4; ?>
</div>
<div class="form-group">
<label>Re-enter Password:</label>
<input type='password' name='cpass' placeholder="Re-enter Password" class='form-control'>
<?php echo $msg5; ?>
</div>
<center><input type='submit' value='submit' name='submit' class='btn btn-success' /></center></br>
<center><a href='login.php'>Already Registered</a></center>
</form>
</div>
</div>
</div>
</body>
</html>
