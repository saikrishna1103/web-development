
function onLoadFunction() {
    gapi.client.setApiKey('AIzaSyCQUGWseYwV-tryIrCMx2OTDNunynkThzQ');
    gapi.client.load('plus', 'v1', function() {});

}


window.fbAsyncInit = function() {
    FB.init({
        appId            : '1222184774603886',
        autoLogAppEvents : true,
        xfbml            : true,
        version          : 'v3.2'
    });
    FB.getLoginStatus(function(response) {
        if(response.status === 'connected') {
        }   else if(response.status === 'not_authorized') {

        }else {

        }

    });
};

(function(d, s, id){
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) {return;}
    js = d.createElement(s); js.id = id;
    js.src = "https://connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));