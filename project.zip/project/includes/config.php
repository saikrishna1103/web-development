<?php
$ser="localhost";
$user="root";
$pass="";
$db="project";

$con=mysqli_connect($ser, $user ,$pass, $db) or die("Connection Failed");

?>
